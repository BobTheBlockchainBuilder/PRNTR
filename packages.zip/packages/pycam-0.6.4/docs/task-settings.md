Task settings
=============
Toolpaths are generated in tasks, which are formed by a combination of a tool, a process, bounds, and zero or more collision models. This way it is possible to make different combinations for different steps in the milling process.
