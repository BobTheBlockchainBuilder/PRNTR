-   <http://www.instructables.com/id/Open-Source-CNC-Toolpathing-Workflow/>
    -- this video shows how to turn a picture via Gimp, Inkscape and
    PyCAM into GCode
-   <http://fablabamersfoort.nl/downloads/fablab-instructable.pdf> --
    how to set up a FabLab in seven days
-   <http://wiki.protospace.nl/index.php/GeneratingGcodeWithPycam> --
    turn a puzzle-like shape into GCode
-   <http://popcon2.net/package/pycam.html> -- PyCAM installed by Ubuntu
    users (registered via popcon)
-   <http://opensourceecology.org/wiki/Industrial_Robot_Mechanical_Design#Toolchain_for_Toolpaths_.28Mechanical.29>
    -- modeling chain description
-   <http://www.mechanicaldesignforum.com/forum/kb.php?a=22> (as
    [HTML](http://cr4.globalspec.com/blogentry/16801/OpenSource-CNC-From-CAD-to-FAB))
    -- using PyCAM or Blender for toolpath generation
-   <http://fablabamersfoort.nl/?nl/Mantis+handleiding> (nl) -- using
    PyCAM with a Mantis machine
-   <http://wiki.dingfabrik.de/index.php/Geraete:Basic_540_CNC> (german)
    -- generating a gear wheel toolpath
-   <http://www.resinaddict.com/forum/viewtopic.php?f=3&t=443> -- using
    a Walther 2520
-   <http://wiki.zentoolworks.com/index.php/Concept_to_cut_tutorial> --
    short review of some CAD/CAM packages
-   <http://replicat.org/generators> -- list of GCode generators at
    <http://replicat.org>
-   <http://wiki.protospace.nl/index.php/Generating3DGcodeWithPycam> -
    very concise howto
-   <http://cncprinter.blogspot.com/2010/11/pycam-emc2.html> - very
    short article
-   <http://gpl.coulmann.de/cnc/cam_talk_1.0.pdf> -- presentation about
    CAM software and format converters (2009)
